class PhoneValidationError(Exception):
    pass


class BirthdayValidationError(Exception):
    pass


class MailValidationError(Exception):
    pass


class AdressValidationError(Exception):
    pass
